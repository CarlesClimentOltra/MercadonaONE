package com.mercadona.shopone;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MercadonaShopOneTest {

    @Test
    void itemGenereicNotExpired() {
        Item[] items = new Item[] { new Item("yogurt", 4, 22) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("yogurt", app.items[0].name);
        assertEquals(3, app.items[0].sellIn);
        assertEquals(21, app.items[0].quality);
    }
    
    @Test
    void itemGenereicExpired() {
        Item[] items = new Item[] { new Item("magdalena", 0, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("magdalena", app.items[0].name);
        assertEquals(-1, app.items[0].sellIn);
        assertEquals(8, app.items[0].quality);
    }

    @Test
    void itemAgedBlueCheese() {
        Item[] items = new Item[] { new Item("Aged blue cheese", 2, 5) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Aged blue cheese", app.items[0].name);
        assertEquals(1, app.items[0].sellIn);
        assertEquals(6, app.items[0].quality);
    }
    
    @Test
    void itemHamMore10() {
        Item[] items = new Item[] { new Item("Ham", 13, 8) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(12, app.items[0].sellIn);
        assertEquals(9, app.items[0].quality);
    }
    
    @Test
    void itemHamMore5() {
        Item[] items = new Item[] { new Item("Ham", 8, 8) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(7, app.items[0].sellIn);
        assertEquals(10, app.items[0].quality);
    }
    
    @Test
    void itemHam() {
        Item[] items = new Item[] { new Item("Ham", 3, 8) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Ham", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(11, app.items[0].quality);
    }
    
    @Test
    void itemIodizedSalt() {
        Item[] items = new Item[] { new Item("Iodized salt", 2, 1) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Iodized salt", app.items[0].name);
        assertEquals(2, app.items[0].sellIn);
        assertEquals(1, app.items[0].quality);
    }
    
    @Test
    void itemFrozenCakeNotExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", 2, 10) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(1, app.items[0].sellIn);
        assertEquals(8, app.items[0].quality);
    }
    
    @Test
    void itemFrozenCakeExpired() {
        Item[] items = new Item[] { new Item("Frozen cake", -1, 2) };
        MercadonaShopOne app = new MercadonaShopOne(items);
        app.updateQuality();
        assertEquals("Frozen cake", app.items[0].name);
        assertEquals(-2, app.items[0].sellIn);
        assertEquals(0, app.items[0].quality);
    }
    
    
    
}
