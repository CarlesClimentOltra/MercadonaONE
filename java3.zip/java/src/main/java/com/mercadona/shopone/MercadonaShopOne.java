package com.mercadona.shopone;

public class MercadonaShopOne {
    Item[] items;

    public MercadonaShopOne(Item[] items) {
        this.items = items;
    }

    public void updateQuality() {
        
        for (Item item: items) {
            
            if ((item.name.equals("Aged blue cheese") || item.name.equals("Ham"))) {
                         
                sumaQuality(item);

                if (item.name.equals("Ham") && item.sellIn < 11) {
                         
                    sumaQuality(item);
                        
                    if (item.sellIn < 6) {
                        
                        sumaQuality(item);
                        
                    }
                        
                }
                   
            }
            
            else {
                
                if (!item.name.equals("Iodized salt")) {
   
                    restaQuality(item);
                    
                    if (item.name.equals("Frozen cake")) {
                        restaQuality(item);
                    }
                
                }
                
            }
            
            if (!item.name.equals("Iodized salt")) {
                restaSellIn(item);
            }
            
            //Cuando haya caducado
            if (item.sellIn < 0) {
                
                if (!item.name.equals("Aged blue cheese")) {
                    
                    if (!item.name.equals("Ham")) {
                        
                        if (!item.name.equals("Iodized salt")) {
                                 
                            restaQuality(item);
                                
                            if (item.name.equals("Frozen cake")) {
                                                                           
                                restaQuality(item);
                                                                      
                            }
   
                        }
                        
                    } 
                    
                    else {
                        
                        restaQuality(item);
                        
                    }
                    
                } 
                
                else {
                    
                    sumaQuality(item);
                    
                }
                
            }
            //Fin caducado
            
        }
        
    }
    
    public void sumaQuality(Item item) {
        
        if (item.quality < 50) {
            item.quality++;
        }
        
    }
    
    public void restaQuality(Item item) {

        if (item.quality >0) {
            item.quality--;
        }
        
        
    }
    
    public void sumaSellIn(Item item) {

        item.sellIn++;
        
    }
    
    public void restaSellIn(Item item) {

        item.sellIn--;
        
    }
    
}

